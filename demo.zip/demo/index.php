<?php

namespace demo;
require 'vendor/autoload.php';

// Using Medoo namespace
use Medoo\Medoo;
use QL\QueryList;
use QL\Ext\PhantomJs;
use QL\Ext\AbsoluteUrl;

// 报告 runtime 错误
error_reporting(E_ERROR | E_WARNING | E_PARSE);
//设置最大执行时间
set_time_limit(0);

class Test
{

    public static $db = false;      //DB类
    public $ql = false;     //模拟请求类
    public $_url = false;   //url和域名
    public static $status;  //远程端口状态
    public static $error = array();     //错误信息
    public static $success = array();

    /**
     *  js模拟请求
     */
    public function __construct()
    {
        // Initialize
        self::$db = new Medoo([
            'database_type' => 'mysql',
            'database_name' => 'openapi',
            'server' => 'localhost',
            'username' => 'root',
            'password' => 'root'
        ]);

        $ql = QueryList::getInstance();

        //需要设置PhantomJS二进制文件路径,phantomjs要事先安装好
        $ql->use(PhantomJs::class, '/usr/local/bin/phantomjs');

        //或者利用自定义的方法来请求
        //$ql->use(PhantomJs::class,'/usr/local/bin/phantomjs','browser');

        // Windows下操作,注意：路径里面不能有空格或中文之类的
        $this->ql = $ql->use(PhantomJs::class, 'E:/program/phantomjs/phantomjs.exe');

    }


    /**
     * 检查url
     * @param $ips
     */
    public function check_url($url)
    {

        $this->_url = trim($url);
        $data = $this->ql->browser(function (\JonnyW\PhantomJs\Http\RequestInterface $r) {
            $r->setMethod('GET');
            $r->setUrl($this->_url);
            $r->setTimeout(10000); // 10 s
            $r->setDelay(3); // 3 s
            return $r;
        })->rules([
            'title' => ['class', 'title-box'],
        ])->query()->getData();
        print_r($data->all());

    }


    /**
     * Notes:通过网关验证部署好的FPM主机
     * create_User: tenger
     * @param $url
     * @param int $port
     * @param bool $is_https
     */
    public function check_remote_url($url, $port = 8080, $is_https = false)
    {

        //是否为https请求
        $http = $is_https ? ('https://' . $url . ':' . $port) : ('http://' . $url . ':' . $port);

        //模拟post的请求
        $this->ql->post($http, [
            'api' => 'utils.util.sessionid',
            'version' => '1.0'
        ], [
            'timeout' => 30,
            'headers' => [
                "Content-Type" => 'application/x-www-form-urlencoded',
                "OA-App-Key" => 1001520,
                'Accept' => 'application/json',
                'User-Agent' => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3278.0 Safari/537.36'
            ]
        ]);
        $result = $this->ql->getHtml();
        self::$success[] =  json_decode($result);

    }


    /**
     * Notes:创建临时表
     * create_User: tenger
     *
     * @return bool
     */
    public function create_temp_table()
    {

        try {

            //查询数据表是否存在着
            $info = self::$db->query(
                "SELECT COUNT(1) AS flag FROM information_schema.tables WHERE table_schema='openapi' AND table_name = 'temp_shared_spo';"
            )->fetch();

            //表不存在则新建临时表
            if (!$info['flag']) {
                self::$db->query("CREATE TABLE `temp_shared_spo` LIKE `shared_spo`;");
            }

            //复制数据到临时表中
            self::$db->query("INSERT INTO `temp_shared_spo` SELECT * FROM `shared_spo`;");

            //验证数据是否已经生成好
            $data = self::$db->get("temp_shared_spo", "communication_addr", [
                "id" => 1
            ]);

            if (empty($data)) {
                throw new Exception('获取临时表数据失败~');
            } else {
                self::$success[] = array('suceess' => '建表成功', 'code' => 200);
            }
        } catch (Exception $e) {//捕获异常
            self::$error[] = $e->getMessage();
        }
    }

    /**
     * 获取ip
     * @return array
     */
    public function get_ips()
    {

        $data = self::$db->get('shared_spo', [
            'communication_addr[JSON]'
        ], [
            'id' => 1
        ]);

        $ips = $data['communication_addr'];

        return $ips;

    }


    /**
     * 新增FPM主机IP操作
     * @param $ip
     * @param int $port
     * @return bool|mixed|null|string|string[]
     */
    public function update_ip($ip, $port = 8080)
    {

        //获取原数据库的ip字段
        $old_ips = $this->get_ips();

        //把新的ip字段添加进去
        array_push($old_ips, $ip . ':' . $port);

        //json格式更新操作
        $info = self::$db->update('temp_shared_spo', [
            "communication_addr[JSON]" => $old_ips
        ], [
            "id" => 1
        ]);

        if ($info->rowCount()) {
            self::$success[] = array('success' => $ip . ' 更新成功', 'code' => 200, 'update' => self::$db->last());
            return self::$db->last();
        } else {
            self::$error[] = array('error' => $ip . ' 更新失败~', 'error_info' => self::$db->last(), 'code' => 30003);
            return false;
        }
    }

    /**
     * 模拟header头访问远程FPM状态
     * @param $ip ip地址或域名
     * @param bool $is_https 是否使用https访问，默认为http
     */
    public function check_fpm_status($ip, $is_https = false)
    {
        //组装ip或域名
        $ip = $is_https ? 'https://' . $ip : 'http://' . $ip;

        $this->ql->get($ip, [
            'param1' => 'testvalue',
            'params2' => 'somevalue'
        ], [
            'headers' => [
                'Referer' => 'https://www.hao123.com/',
                'User-Agent' => 'testing/1.0',
                'Accept' => 'application/json',
                'X-Foo' => ['Bar', 'Baz'],
                'Cookie' => 'abc=111;xxx=222'
            ]
        ]);
        echo $this->ql->getHtml();
    }


    /**
     * 绑定本地host文件
     * @param $ip
     * @param $domain
     * @return bool|string
     */
    public function add_host($ip, $domain)
    {

        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            self::$error[] = array('error' => '请输入正确的IP地址~', 'code' => 2001);
            return false;
        } else if (empty($domain)) {
            self::$error[] = array('error' => '请填写域名~', 'code' => 2002);
            return false;
        } else {
            $newdomain = $ip . ' ' . $domain . PHP_EOL;
            if (strcasecmp(PHP_OS, 'WINNT') === 0) {
                // Windows 服务器下
                if (file_put_contents('C:\Windows\System32\drivers\etc\hosts', $newdomain, FILE_APPEND)) {
                    self::$success[] = array('success' => '绑定域名成功~', 'code' => 200);
                    return true;
                } else {
                    self::$error[] = array('error' => '绑定域名失败~', 'code' => 2005);
                    return false;
                }
            } elseif (strcasecmp(PHP_OS, 'Linux') === 0) {
                // Linux 服务器下
                if (file_put_contents('/etc/hosts', $newdomain, FILE_APPEND)) {
                    self::$success[] = array('success' => '添加成功~', 'code' => 200);
                    return true;
                } else {
                    self::$error[] = array('error' => '绑定域名失败~', 'code' => 2005);
                    return false;
                }
            }

        }
    }


    /**
     * 检测能否ping通IP或域名
     * @param type $address IP地址或域名地址
     * @return boolean
     */
    public function ping_address($address)
    {
        $status = -1;
        if (strcasecmp(PHP_OS, 'WINNT') === 0) {
            // Windows 服务器下
            $pingresult = exec("ping -n 1 {$address}", $outcome, $status);
        } elseif (strcasecmp(PHP_OS, 'Linux') === 0) {
            // Linux 服务器下
            $pingresult = exec("ping -c 1 {$address}", $outcome, $status);
        }

        if (0 == $status) {
            self::$success[] = array('success' => "请求ip: " . $address . " 成功~", 'code' => 200);
            return true;
        } else {
            self::$error[] = array('error' => "请求ip: " . $address . " 失败~", 'code' => 2003);
            return false;
        }
    }


    /**
     * 验证远程ip的端口是否开启
     * @param $ip
     * @param $port
     * @return int
     */
    public function check_remote_port($ip, $port = 8080)
    {
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            self::$error[] = array('error' => '请输入正确的IP地址~', 'code' => 2001);
            return false;
        }

        $sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
//        socket_set_option($sock, SOL_SOCKET, SO_REUSEADDR, 1);   //每次请求后注意关闭连接
        socket_set_nonblock($sock);
        socket_connect($sock, $ip, $port);
        socket_set_block($sock);
        self::$status = socket_select($r = array($sock), $w = array($sock), $f = array($sock), 5);
        $info = self::check_status($ip, $port);
        return $info;
    }


    /**
     * 返回远程端口号验证结果
     */
    public static function check_status($ip, $port)
    {
        $host = $ip . ': ' . $port;
        switch (self::$status) {
            case 2:
                self::$error[] = array('error' => $host . ' 端口未开启', 'code' => 4002);
                return false;
            case 1:
                self::$success[] = array('success' => $host . ' 端口正常', 'code' => 200);
                return true;
            case 0:
                self::$error[] = array('error' => $host . ' 连接超时', 'code' => 4001);
                return false;
        }
    }


    /**
     * 对内外网的ip分组
     * @param $datas
     * @return array
     */
    public function deal_ip_array($outips, $inips)
    {
        $ip_arr = array();
        if (is_array($outips)) {
            foreach ($outips as $k => $v) {
                list($ip, $port) = explode(':', $v);
                if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                    self::$error[] = array('error' => $ip . ' 不正确,请输入正确的IP地址~', 'code' => 2001);
                }
                //key为 ip，值为端口
                $ip_arr[$ip] = $port;

            }

            return $ip_arr;
        }
    }

    /**
     * 提示信息
     * @param $data
     */
    public static function tips($data)
    {
        echo json_encode($data);
    }

}


$Check_Obj = new Test();

if ($_POST) {
    $info = $_POST;
    $step = $info['step'];
    $outips = $_POST['outip'];
    $inips = $_POST['inip'];
    $return_data = array();

    $ip_port = ($Check_Obj->deal_ip_array($outips, $inips));

    //获取ip和端口
    foreach($ip_port as $key => $val){
        $info['ip'] = trim($key);
        $info['port'] = trim($val);
    }


    for ($i = 1; $i <= 5; $i++) {

            switch ($i) {
                case 1:
                    $ip = trim($info['ip']); //用户ip
                    $port = trim($info['port']); //需要验证的端口

                    //验证ip和端口是否正常
                    $check_result = $Check_Obj->check_remote_port($ip, $port);
                    break;
                case 2:
                    $ip = trim($info['ip']); //用户ip
                    $domain = trim($info['domain']); //要绑定的域名

                    //修改host文件，绑定域名
//                    $check_result = $Check_Obj->add_host($ip, $domain);
                    break;
                case 3:
                    $url = $info['ip'];
                    $port = trim($info['port']);
                    $check_result = $Check_Obj->check_remote_url($url);
                    break;
                case 4:
                    $url = $info['ip'];
                    $port = trim($info['port']);
                    $check_result = $Check_Obj->create_temp_table();
                    break;
                case 5:
                    $url = $info['ip'];
                    $port = trim($info['port']);
                    $check_result = $Check_Obj->update_ip($url, $port);
                    break;
            }
        }

        if($Check_Obj::$error || $Check_Obj::$success){
            $return_data['success'] = $Check_Obj::$success;
            $return_data['error'] = $Check_Obj::$error;
            echo json_encode($return_data);
        }



    }




